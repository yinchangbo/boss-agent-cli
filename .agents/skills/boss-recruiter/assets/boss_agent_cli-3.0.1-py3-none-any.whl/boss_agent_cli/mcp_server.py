"""MCP Server for boss-agent-cli — 让 Claude Desktop / Cursor 直接调用 BOSS 直聘求职工具。

工具目录 `TOOLS` 在 `mcp_tools`，工具名 → CLI 参数的映射在 `mcp_args`；
本模块只保留服务器实例、CLI 调用、传输层与入口。两者的公开符号在下方原样再导出，
`mcp-server/server.py` wrapper 与既有测试的导入路径因此保持不变。
"""

import argparse
import asyncio
import json
import math
import signal
import subprocess
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any, cast

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
	CallToolRequestParams,
	CallToolResult,
	ListToolsResult,
	PaginatedRequestParams,
	TextContent,
)

from boss_agent_cli.api.browser_source import POLICIES as BROWSER_SOURCES
from boss_agent_cli.mcp_args import _build_args
from boss_agent_cli.mcp_tools import TOOLS
from boss_agent_cli.output import envelope_error

# 向后兼容的再导出：这些符号在拆分前属于本模块，`mcp-server/server.py` wrapper
# 与既有测试仍按 `boss_agent_cli.mcp_server.<name>` 取用。本模块自身不再使用它们，
# 故显式标注 F401——删掉会静默破坏 wrapper 和测试的导入路径。
from boss_agent_cli.mcp_tools import (  # noqa: F401
	_LOW_RISK_BLOCKED_TOOLS,
	_MCP_TOOL_COMPLIANCE_COMMAND_OVERRIDES,
	_SCHEMA_WITH_AVAILABILITY,
	_availability_of,
	_build_schema_with_availability,
	_compliance_command_for_tool,
	_crawl_task_tools,
	_decorate_tool_descriptions,
	_is_low_risk_blocked_tool,
	_tool_availability,
)

__all__ = [
	"SERVER_INSTRUCTIONS",
	"TOOLS",
	"call_tool",
	"list_tools",
	"main",
	"run",
	"server",
]

if TYPE_CHECKING:
	# SSE / HTTP 传输是可选路径，starlette 与 session manager 只在对应工厂函数里
	# 惰性导入；这里仅为类型标注引入，不影响 stdio 传输的启动开销。
	from collections.abc import AsyncIterator

	from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
	from starlette.applications import Starlette
	from starlette.types import Receive, Scope, Send

SERVER_INSTRUCTIONS = (
	"boss-agent-cli over MCP exposes all implemented candidate, recruiter, communication and crawl tools. "
	"Historical assisted and research configurations have identical capability access; platform adapters may still "
	"return NOT_SUPPORTED when an operation is not implemented. Every tool returns the same JSON envelope "
	"{ok, data, pagination, error, hints}; when ok is false, read error.code and error.recovery_action and "
	"act on it (for example AUTH_REQUIRED means the user runs boss login). boss schema is the capability "
	"source of truth — do not hardcode command tables."
	" For hr_greet, preview with dry_run and obtain explicit operator approval for that candidate and message "
	"before setting yes=true. Never infer approval or retry a confirmation failure with yes=true on your own. "
	"An uncertain send result requires conversation verification, not another send. "
	"After a post-send error, inspect error.details.sent and stop; a sent greeting must not be repeated."
)

server = Server(
	"boss-agent-cli",
	instructions=SERVER_INSTRUCTIONS,
)
DEFAULT_TRANSPORT = "stdio"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
DEFAULT_HTTP_PATH = "/mcp"
DEFAULT_SSE_PATH = "/sse"
DEFAULT_MESSAGE_PATH = "/messages/"
DEFAULT_BOSS_BIN = "boss"
_BOSS_BIN = DEFAULT_BOSS_BIN
_BOSS_GLOBAL_ARGS: list[str] = []
_CLI_TIMEOUT_SECONDS = 120.0
_CHECKPOINT_GRACE_SECONDS = 5.0
_TERMINATE_GRACE_SECONDS = 1.0


def _configure_boss_invocation(
	*,
	boss_bin: str = DEFAULT_BOSS_BIN,
	data_dir: str | None = None,
	platform: str | None = None,
	role: str | None = None,
	browser_source: str | None = None,
) -> None:
	"""Configure global flags passed from the MCP host to the underlying boss CLI."""
	global _BOSS_BIN, _BOSS_GLOBAL_ARGS
	_BOSS_BIN = boss_bin
	args: list[str] = []
	if data_dir:
		args.extend(["--data-dir", data_dir])
	if platform:
		args.extend(["--platform", platform])
	if role:
		args.extend(["--role", role])
	if browser_source:
		args.extend(["--browser-source", browser_source])
	_BOSS_GLOBAL_ARGS = args


def _cli_timeout(args: tuple[str, ...]) -> float:
	# A wizard deadline belongs to the child. The host allows bounded extra
	# time for that child to commit its result/checkpoint and emit the envelope.
	if args and args[0] == "wizard" and "--timeout" in args:
		try:
			requested = float(args[args.index("--timeout") + 1])
		except (IndexError, ValueError):
			return _CLI_TIMEOUT_SECONDS
		if math.isfinite(requested) and requested > 0:
			return requested + _CHECKPOINT_GRACE_SECONDS
	return _CLI_TIMEOUT_SECONDS


def _cli_failure(args: tuple[str, ...], code: str, message: str, **details: Any) -> dict[str, Any]:
	command = args[0] if args else "mcp"
	if command in {"agent", "hr", "ai", "resume", "watch", "crawl"} and len(args) > 1:
		command = f"{command}.{args[1]}"
	return cast(
		"dict[str, Any]",
		json.loads(
			envelope_error(
				command,
				code=code,
				message=message,
				recoverable=code != "CLI_ERROR" and not details.get("outcome_unknown", False),
				recovery_action="检查本地 checkpoint 与平台实际结果，再显式恢复；未确认的写操作不要直接重试",
				details=details or None,
			)
		),
	)


def _parse_cli_output(args: tuple[str, ...], stdout: str, stderr: str) -> dict[str, Any]:
	try:
		parsed = json.loads(stdout)
	except json.JSONDecodeError:
		parsed = None
	if isinstance(parsed, dict):
		return parsed
	# CLI 契约保证 stdout 是 JSON 信封对象；拿到别的形状（解析失败或非对象）
	# 一律按命令失败处理，而不是把非 dict 结果透传给调用方。
	return _cli_failure(args, "CLI_ERROR", stderr or "命令执行失败")


def _run_boss(*args: str) -> dict[str, Any]:
	"""Synchronous compatibility entrypoint; MCP handlers use the async path."""
	cmd = [_BOSS_BIN, "--json", *_BOSS_GLOBAL_ARGS, *args]
	try:
		result = subprocess.run(
			cmd,
			capture_output=True,
			text=True,
			timeout=_cli_timeout(args),
			stdin=subprocess.DEVNULL,
		)
	except subprocess.TimeoutExpired:
		return _cli_failure(args, "WORKFLOW_TIMEOUT", "底层 CLI 超时", outcome_unknown=True)
	except OSError as exc:
		return _cli_failure(args, "CLI_ERROR", str(exc))
	return _parse_cli_output(args, result.stdout, result.stderr)


async def _stop_cli_process(
	process: asyncio.subprocess.Process,
	output: "asyncio.Task[tuple[bytes, bytes]]",
) -> tuple[bytes, bytes]:
	if process.returncode is None:
		# SIGINT gives wizard/automation their normal interruption checkpoint
		# path. Never signal the user's attached browser process.
		try:
			process.send_signal(signal.SIGINT)
		except ProcessLookupError:
			pass
		except ValueError:
			try:
				process.terminate()
			except ProcessLookupError:
				pass
	try:
		return await asyncio.wait_for(asyncio.shield(output), _CHECKPOINT_GRACE_SECONDS)
	except asyncio.TimeoutError:
		if process.returncode is None:
			try:
				process.terminate()
			except ProcessLookupError:
				pass
	try:
		return await asyncio.wait_for(asyncio.shield(output), _TERMINATE_GRACE_SECONDS)
	except asyncio.TimeoutError:
		if process.returncode is None:
			try:
				process.kill()
			except ProcessLookupError:
				pass
		try:
			return await asyncio.wait_for(asyncio.shield(output), _TERMINATE_GRACE_SECONDS)
		except asyncio.TimeoutError:
			# An inherited pipe held by another process must not turn cleanup into
			# an unbounded wait after the owned CLI has been killed.
			output.cancel()
			await asyncio.gather(output, return_exceptions=True)
			return b"", b""


async def _run_boss_async(*args: str) -> dict[str, Any]:
	if args and args[0] == "wizard" and not any(flag in args for flag in ("--timeout", "--status", "--stop")):
		args = (*args, "--timeout", str(_CLI_TIMEOUT_SECONDS))
	cmd = [_BOSS_BIN, "--json", *_BOSS_GLOBAL_ARGS, *args]
	spawn = asyncio.create_task(
		asyncio.create_subprocess_exec(
			*cmd,
			stdout=asyncio.subprocess.PIPE,
			stderr=asyncio.subprocess.PIPE,
			stdin=asyncio.subprocess.DEVNULL,
		)
	)
	try:
		process = await asyncio.shield(spawn)
	except OSError as exc:
		return _cli_failure(args, "CLI_ERROR", str(exc))
	except asyncio.CancelledError:
		try:
			process = await asyncio.shield(spawn)
		except OSError:
			return _cli_failure(args, "WORKFLOW_STOPPED", "MCP 调用已取消", outcome_unknown=False)
		output = asyncio.create_task(process.communicate())
		await asyncio.shield(_stop_cli_process(process, output))
		return _cli_failure(args, "WORKFLOW_STOPPED", "MCP 调用已取消", outcome_unknown=True)
	output = asyncio.create_task(process.communicate())
	try:
		stdout, stderr = await asyncio.wait_for(asyncio.shield(output), _cli_timeout(args))
	except (asyncio.TimeoutError, asyncio.CancelledError) as exc:
		stdout, _ = await asyncio.shield(_stop_cli_process(process, output))
		code = "WORKFLOW_STOPPED" if isinstance(exc, asyncio.CancelledError) else "WORKFLOW_TIMEOUT"
		# A child envelope can carry the committed checkpoint/run id. Preserve it
		# inside the failure; killing a child never proves an action had no effect.
		try:
			checkpoint_result = json.loads(stdout)
		except (json.JSONDecodeError, UnicodeDecodeError):
			checkpoint_result = None
		return _cli_failure(
			args,
			code,
			"MCP 调用已取消" if code == "WORKFLOW_STOPPED" else "底层 CLI 超时",
			outcome_unknown=True,
			checkpoint_result=checkpoint_result if isinstance(checkpoint_result, dict) else None,
		)
	return _parse_cli_output(args, stdout.decode("utf-8", errors="replace"), stderr.decode("utf-8", errors="replace"))


# ── Handler 注册（mcp 2.x） ────────────────────────────────────────
#
# 2.0 移除了 `@server.list_tools()` / `@server.call_tool()` 装饰器，改为
# `add_request_handler(method, params_type, handler)`。除注册方式外还有两处变化：
#   1. handler 签名从「按需取参」变成固定的 `(ctx, params)`；
#   2. 返回值从裸 list 变成 Result 对象（`ListToolsResult` / `CallToolResult`）。
# 本段的形状照抄 SDK 自身在 `mcp/server/mcpserver/server.py` 的注册与 handler 写法，
# 不是从文档推测的。


async def list_tools(ctx: Any, params: "PaginatedRequestParams | None" = None) -> ListToolsResult:
	return ListToolsResult(tools=TOOLS)


async def call_tool(ctx: Any, params: CallToolRequestParams) -> CallToolResult:
	args = _build_args(params.name, dict(params.arguments or {}))
	result = await _run_boss_async(*args)
	return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))])


server.add_request_handler("tools/list", PaginatedRequestParams, list_tools)
server.add_request_handler("tools/call", CallToolRequestParams, call_tool)


# ── 入口 ──────────────────────────────────────────────────────────


async def main() -> None:
	async with stdio_server() as (read_stream, write_stream):
		await server.run(read_stream, write_stream, server.create_initialization_options())


def _normalize_path(path: str) -> str:
	if not path.startswith("/"):
		return f"/{path}"
	return path


def _create_sse_app(*, sse_path: str = DEFAULT_SSE_PATH, message_path: str = DEFAULT_MESSAGE_PATH) -> "Starlette":
	from mcp.server.sse import SseServerTransport
	from starlette.applications import Starlette
	from starlette.requests import Request
	from starlette.responses import Response
	from starlette.routing import Mount, Route

	sse_path = _normalize_path(sse_path)
	message_path = _normalize_path(message_path)
	sse = SseServerTransport(message_path)

	async def handle_sse(scope: "Scope", receive: "Receive", send: "Send") -> Response:
		async with sse.connect_sse(scope, receive, send) as streams:
			await server.run(
				streams[0],
				streams[1],
				server.create_initialization_options(),
			)
		return Response()

	async def sse_endpoint(request: Request) -> Response:
		return await handle_sse(request.scope, request.receive, request._send)

	return Starlette(
		routes=[
			Route(sse_path, endpoint=sse_endpoint, methods=["GET"]),
			Mount(message_path, app=sse.handle_post_message),
		]
	)


class _StreamableHTTPASGIApp:
	def __init__(self, session_manager: "StreamableHTTPSessionManager") -> None:
		self.session_manager = session_manager

	async def __call__(self, scope: "Scope", receive: "Receive", send: "Send") -> None:
		await self.session_manager.handle_request(scope, receive, send)


def _create_streamable_http_app(*, path: str = DEFAULT_HTTP_PATH) -> "Starlette":
	from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
	from starlette.applications import Starlette
	from starlette.routing import Route

	path = _normalize_path(path)
	session_manager = StreamableHTTPSessionManager(app=server)
	http_app = _StreamableHTTPASGIApp(session_manager)

	# 必须是 asynccontextmanager：Starlette 对裸 async generator lifespan 会走
	# 弃用路径并发 DeprecationWarning。
	@asynccontextmanager
	async def lifespan(app: "Starlette") -> "AsyncIterator[None]":
		async with session_manager.run():
			yield

	return Starlette(
		routes=[Route(path, endpoint=http_app)],
		lifespan=lifespan,
	)


def _serve_asgi_app(app: "Starlette", *, host: str, port: int) -> None:
	import uvicorn

	uvicorn.run(app, host=host, port=port, log_level="info")


def _run_sse_server(*, host: str, port: int, sse_path: str, message_path: str) -> None:
	app = _create_sse_app(sse_path=sse_path, message_path=message_path)
	_serve_asgi_app(app, host=host, port=port)


def _run_http_server(*, host: str, port: int, path: str) -> None:
	app = _create_streamable_http_app(path=path)
	_serve_asgi_app(app, host=host, port=port)


def _parse_cli_args(argv: list[str] | None = None) -> argparse.Namespace:
	parser = argparse.ArgumentParser(description="Run boss-agent-cli MCP server")
	parser.add_argument(
		"--transport",
		choices=("stdio", "sse", "http"),
		default=DEFAULT_TRANSPORT,
		help="MCP 传输模式（默认 stdio）",
	)
	parser.add_argument("--host", default=DEFAULT_HOST, help="HTTP/SSE 监听地址")
	parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="HTTP/SSE 监听端口")
	parser.add_argument("--path", default=DEFAULT_HTTP_PATH, help="HTTP streaming 路径")
	parser.add_argument("--sse-path", default=DEFAULT_SSE_PATH, help="SSE 建链路径")
	parser.add_argument("--message-path", default=DEFAULT_MESSAGE_PATH, help="SSE 消息回传路径")
	parser.add_argument("--boss-bin", default=DEFAULT_BOSS_BIN, help="底层 boss CLI 可执行文件路径")
	parser.add_argument("--data-dir", default=None, help="传给 boss CLI 的数据目录，用于项目级状态隔离")
	parser.add_argument("--platform", default=None, help="传给 boss CLI 的默认平台，如 zhipin")
	parser.add_argument("--role", choices=("candidate", "recruiter"), default=None, help="传给 boss CLI 的默认角色")
	parser.add_argument(
		"--browser-source",
		# 取值域只从策略表推导，与 main.py / config_cmd.py 一致；新增来源不必再改这里。
		choices=tuple(BROWSER_SOURCES),
		default=None,
		help="传给 boss CLI 的浏览器通道来源（默认 auto）",
	)
	return parser.parse_args(argv)


def run(argv: list[str] | None = None) -> None:
	args = _parse_cli_args(argv)
	_configure_boss_invocation(
		boss_bin=args.boss_bin,
		data_dir=args.data_dir,
		platform=args.platform,
		role=args.role,
		browser_source=args.browser_source,
	)
	if args.transport == "stdio":
		asyncio.run(main())
		return
	if args.transport == "sse":
		_run_sse_server(host=args.host, port=args.port, sse_path=args.sse_path, message_path=args.message_path)
		return
	_run_http_server(host=args.host, port=args.port, path=args.path)


if __name__ == "__main__":
	run()
