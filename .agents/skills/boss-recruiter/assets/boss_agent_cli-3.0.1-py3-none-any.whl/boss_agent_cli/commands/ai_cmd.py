"""AI 简历优化命令组。

子命令：config / analyze-jd / polish / optimize / suggest
"""

import json
from pathlib import Path
from typing import Any, cast

import click

from boss_agent_cli.ai.config import AIConfigStore
from boss_agent_cli.ai.prompts import (
	CHAT_COACH_PROMPT,
	CHAT_REPLY_PROMPT,
	COVER_LETTER_PROMPT,
	INTERVIEW_PREP_PROMPT,
	JD_ANALYSIS_PROMPT,
	RESUME_OPTIMIZE_FOR_JD_PROMPT,
	RESUME_OPTIMIZE_SIMPLE_PROMPT,
	RESUME_POLISH_PROMPT,
	RESUME_SUGGEST_PROMPT,
	SUGGEST_KEYWORDS_PROMPT,
)
from boss_agent_cli.ai.service import AIService, AIServiceError
from boss_agent_cli.cache.store import CacheStore
from boss_agent_cli.display import (
	handle_error_output,
	handle_output,
	render_action_result,
	render_ai_result,
)
from boss_agent_cli.resume.models import resume_to_text
from boss_agent_cli.resume.store import ResumeStore


def _get_ai_config_store(ctx: click.Context) -> AIConfigStore:
	return AIConfigStore(ctx.obj["data_dir"])


def _get_resume_store(ctx: click.Context) -> ResumeStore:
	return ResumeStore(ctx.obj["data_dir"] / "resumes")


def _create_ai_service(ctx: click.Context) -> AIService | None:
	"""从配置创建 AIService 实例，未配置时返回 None。"""
	store = _get_ai_config_store(ctx)
	if not store.is_configured():
		return None
	config = store.load_config()
	api_key = store.get_api_key()
	base_url = store.get_base_url()
	if not api_key or not base_url:
		return None
	return AIService(
		base_url=base_url,
		api_key=api_key,
		model=config["ai_model"],
		temperature=config.get("ai_temperature", 0.7),
		max_tokens=config.get("ai_max_tokens", 4096),
	)


def _require_ai_service(ctx: click.Context) -> AIService | None:
	"""获取 AIService，未配置时输出错误信封并返回 None。"""
	svc = _create_ai_service(ctx)
	if svc is None:
		handle_error_output(
			ctx, "ai",
			code="AI_NOT_CONFIGURED",
			message="AI 服务未配置",
			recoverable=True,
			recovery_action="boss ai config --provider <provider> --model <model> --api-key <key>",
		)
		ctx.exit(1)
		return None
	return svc


def _load_resume_text(ctx: click.Context, resume_name: str) -> str | None:
	"""加载简历纯文本，不存在时输出错误。"""
	store = _get_resume_store(ctx)
	resume = store.get(resume_name)
	if resume is None:
		handle_error_output(
			ctx, "ai",
			code="RESUME_NOT_FOUND",
			message=f"简历 '{resume_name}' 不存在",
		)
		ctx.exit(1)
		return None
	return resume_to_text(resume)


def _call_ai(ctx: click.Context, svc: AIService, prompt: str) -> dict[str, Any] | None:
	"""调用 AI 并解析 JSON 结果，失败时输出错误信封。"""
	try:
		raw = svc.chat([
			{"role": "system", "content": "你是求职顾问。所有输出使用 JSON 格式。"},
			{"role": "user", "content": prompt},
		])
	except AIServiceError as exc:
		handle_error_output(
			ctx, "ai",
			code="AI_API_ERROR",
			message=f"AI 服务调用失败: {exc}",
			recoverable=True,
			recovery_action="检查网络连接和密钥配置，重试",
		)
		ctx.exit(1)
		return None

	# 尝试提取 JSON（兼容 markdown 代码块包裹）
	text = raw.strip()
	if text.startswith("```"):
		lines = text.split("\n")
		lines = [ln for ln in lines if not ln.startswith("```")]
		text = "\n".join(lines).strip()

	try:
		return cast("dict[str, Any]", json.loads(text))
	except json.JSONDecodeError:
		handle_error_output(
			ctx, "ai",
			code="AI_PARSE_ERROR",
			message="AI 返回结果解析失败",
			recoverable=True,
			recovery_action="重试（模型输出不稳定时可能发生）",
		)
		ctx.exit(1)
		return None


def _fit_missing_detail_item(item: dict[str, Any]) -> dict[str, Any]:
	security_id = str(item.get("security_id") or "")
	hint = f"先 boss detail {security_id}" if security_id else "先 boss detail <security_id>"
	return {
		"job_id": item.get("job_id", ""),
		"security_id": security_id,
		"title": item.get("title", ""),
		"company": item.get("company", ""),
		"status": "缺详情",
		"hint": hint,
	}


def _build_fit_prompt(resume_text: str, jobs: list[dict[str, Any]]) -> str:
	payload = {
		"resume": resume_text,
		"jobs": jobs,
		"output_schema": {
			"results": [
				{
					"selector": "string",
					"title": "string",
					"match_score": "0-100 integer",
					"gaps": ["string"],
					"keyword_hits": ["string"],
					"recommendation": "string",
				},
			],
		},
	}
	return (
		"请基于本地简历和已缓存职位详情，逐岗评估匹配度。"
		"只返回 JSON，不要包含 markdown。字段必须符合 output_schema。\n\n"
		f"{json.dumps(payload, ensure_ascii=False)}"
	)


@click.group("ai")
def ai_group() -> None:
	"""AI 简历优化。"""


@ai_group.command("config")
@click.option("--provider", default=None, help="AI 提供商（openai/deepseek/moonshot/openrouter/qwen/zhipu/siliconflow/ollama/vllm/custom）")
@click.option("--model", default=None, help="模型名称（如 gpt-4o / claude-sonnet-4.5 / deepseek-chat）")
@click.option("--api-key", default=None, help="API 密钥（将加密存储）")
@click.option("--base-url", default=None, help="自定义 API 基础地址（provider=custom 或自建代理时使用）")
@click.option("--temperature", default=None, type=float, help="生成温度")
@click.option("--max-tokens", default=None, type=int, help="最大令牌数")
@click.pass_context
def ai_config_cmd(ctx: click.Context, provider: str | None, model: str | None, api_key: str | None, base_url: str | None, temperature: float | None, max_tokens: int | None) -> None:
	"""查看或设置 AI 服务配置"""
	store = _get_ai_config_store(ctx)

	# 无参数时显示当前配置
	has_updates = any([provider, model, api_key, base_url, temperature is not None, max_tokens is not None])
	if not has_updates:
		config = store.load_config()
		config["api_key_set"] = store.get_api_key() is not None
		config.pop("ai_api_key", None)
		# 回显解析后的实际端点：只设 --provider 时 ai_base_url 是空的，
		# 真正生效的地址来自 PROVIDER_BASE_URLS 查表，用户此前无从确认。
		# provider 名相近时（如 openrouter / orcarouter）记混会把 API key 与
		# 简历全文发到另一家，而界面上看不出任何差别。
		config["resolved_base_url"] = store.get_base_url()
		handle_output(
			ctx, "ai-config", config,
			render=lambda d: render_action_result(
				d, title="ai config", next_steps=["boss ai local status", "boss ai analyze-jd <security_id>"]
			),
			hints={"next_actions": [
				"boss ai config --provider openai --model gpt-4o --api-key <key>",
				"boss ai local configure --runtime ollama --model qwen3:14b",
			]},
		)
		return

	# 有参数时更新配置
	updates: dict[str, Any] = {}
	if provider is not None:
		updates["ai_provider"] = provider
	if model is not None:
		updates["ai_model"] = model
	if base_url is not None:
		updates["ai_base_url"] = base_url
	if temperature is not None:
		updates["ai_temperature"] = temperature
	if max_tokens is not None:
		updates["ai_max_tokens"] = max_tokens
	if updates:
		store.save_config(**updates)
	if api_key is not None:
		store.save_api_key(api_key)

	handle_output(
		ctx, "ai-config",
		{
			"action": "update",
			"updated_fields": list(updates.keys()) + (["api_key"] if api_key else []),
			# 写入后立刻回显生效的端点，让「刚配的这个 provider 会把数据发去哪」
			# 在同一屏内可确认，而不是要再跑一次 boss ai config 才看得到。
			"resolved_base_url": store.get_base_url(),
		},
		render=lambda d: render_action_result(d, title="ai config", next_steps=["boss ai config"]),
		hints={"next_actions": ["boss ai config", "boss ai local status", "boss ai analyze-jd <security_id> --resume <name>"]},
	)


@ai_group.command("analyze-jd")
@click.argument("jd_text")
@click.option("--resume", "resume_name", required=True, help="对比的本地简历名称")
@click.pass_context
def ai_analyze_jd_cmd(ctx: click.Context, jd_text: str, resume_name: str) -> None:
	"""分析职位描述并评估简历匹配度

	JD_TEXT 可以是职位描述文本，也可以是 @文件路径 读取文件内容。
	"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	# 支持 @file 语法读取文件
	if jd_text.startswith("@"):
		file_path = Path(jd_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		jd_text = file_path.read_text(encoding="utf-8")

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	prompt = JD_ANALYSIS_PROMPT.format(jd_text=jd_text, resume_text=resume_text)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-analyze-jd", result,
		render=lambda d: render_ai_result(d, title="ai-analyze-jd"),
		hints={"next_actions": [
			f"boss ai optimize {resume_name} --jd <jd_text>",
			f"boss ai suggest {resume_name} --jd <jd_text>",
		]},
	)


@ai_group.command("polish")
@click.argument("resume_name")
@click.pass_context
def ai_polish_cmd(ctx: click.Context, resume_name: str) -> None:
	"""通用简历润色优化"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	prompt = RESUME_POLISH_PROMPT.format(resume_text=resume_text)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-polish", result,
		render=lambda d: render_ai_result(d, title="ai-polish"),
		hints={"next_actions": [f"boss resume show {resume_name}"]},
	)


@ai_group.command("optimize")
@click.argument("resume_name")
@click.option("--jd", "jd_text", required=True, help="目标职位描述文本或 @文件路径")
@click.pass_context
def ai_optimize_cmd(ctx: click.Context, resume_name: str, jd_text: str) -> None:
	"""基于目标职位描述优化简历"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	if jd_text.startswith("@"):
		file_path = Path(jd_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		jd_text = file_path.read_text(encoding="utf-8")

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	prompt = RESUME_OPTIMIZE_FOR_JD_PROMPT.format(jd_text=jd_text, resume_text=resume_text)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-optimize", result,
		render=lambda d: render_ai_result(d, title="ai-optimize"),
		hints={"next_actions": [
			f"boss resume show {resume_name}",
			f"boss resume export {resume_name} --format pdf",
		]},
	)


@ai_group.command("suggest")
@click.argument("resume_name")
@click.option("--jd", "jd_text", required=True, help="目标职位描述文本或 @文件路径")
@click.pass_context
def ai_suggest_cmd(ctx: click.Context, resume_name: str, jd_text: str) -> None:
	"""基于目标职位描述给出改进建议（不修改简历）"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	if jd_text.startswith("@"):
		file_path = Path(jd_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		jd_text = file_path.read_text(encoding="utf-8")

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	prompt = RESUME_SUGGEST_PROMPT.format(jd_text=jd_text, resume_text=resume_text)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-suggest", result,
		render=lambda d: render_ai_result(d, title="ai-suggest"),
		hints={"next_actions": [
			f"boss ai optimize {resume_name} --jd <jd_text>",
			f"boss resume show {resume_name}",
		]},
	)


@ai_group.command("fit")
@click.option("--resume", "resume_name", required=True, help="本地简历名称")
@click.option("--limit", default=20, type=click.IntRange(min=1), help="最多分析的候选池职位数")
@click.pass_context
def ai_fit_cmd(ctx: click.Context, resume_name: str, limit: int) -> None:
	"""基于本地简历和候选池缓存详情生成逐岗匹配报告。"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
		shortlist = cache.list_shortlist()[:limit]
		jobs: list[dict[str, Any]] = []
		missing: list[dict[str, Any]] = []
		for item in shortlist:
			job_id = str(item.get("job_id") or "")
			description = cache.get_job_desc(job_id)
			if description:
				jobs.append({
					"job_id": job_id,
					"security_id": item.get("security_id", ""),
					"title": item.get("title", ""),
					"company": item.get("company", ""),
					"city": item.get("city", ""),
					"salary": item.get("salary", ""),
					"description": description,
				})
			else:
				missing.append(_fit_missing_detail_item(item))

	if not shortlist:
		handle_output(
			ctx,
			"ai-fit",
			{"results": [], "missing": [], "summary": {"analyzed": 0, "missing_details": 0}},
			render=lambda d: render_ai_result(d, title="ai-fit"),
			hints={"next_actions": ["boss shortlist add <security_id> <job_id>"]},
		)
		return

	if not jobs:
		handle_output(
			ctx,
			"ai-fit",
			{"results": [], "missing": missing, "summary": {"analyzed": 0, "missing_details": len(missing)}},
			render=lambda d: render_ai_result(d, title="ai-fit"),
			hints={"next_actions": ["先对候选池职位执行 boss detail <security_id> 缓存详情后重试"]},
		)
		return

	result = _call_ai(ctx, svc, _build_fit_prompt(resume_text, jobs))
	if result is None:
		return

	result.setdefault("results", [])
	result["missing"] = missing
	result["summary"] = {
		"analyzed": len(jobs),
		"missing_details": len(missing),
	}
	handle_output(
		ctx,
		"ai-fit",
		result,
		render=lambda d: render_ai_result(d, title="ai-fit"),
		hints={"next_actions": [f"boss ai optimize {resume_name} --jd <jd_text>"]},
	)


@ai_group.command("reply")
@click.argument("recruiter_message")
@click.option("--context", default="", help="会话上下文（可选，或 @文件路径）")
@click.option("--resume", "resume_name", default=None, help="参考简历名称（可选）")
@click.option("--tone", default="简洁专业", type=click.Choice(["简洁专业", "热情积极", "谨慎确认"]), help="语气偏好")
@click.pass_context
def ai_reply_cmd(ctx: click.Context, recruiter_message: str, context: str, resume_name: str | None, tone: str) -> None:
	"""基于招聘者消息生成回复草稿（2-3 条候选）

	RECRUITER_MESSAGE 为招聘者发来的消息文本，或 @文件路径 读取文件内容。
	"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	def _resolve_text(value: str) -> str:
		if value.startswith("@"):
			file_path = Path(value[1:])
			if not file_path.exists():
				handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
				ctx.exit(1)
			return file_path.read_text(encoding="utf-8")
		return value

	recruiter_message = _resolve_text(recruiter_message)
	context_text = _resolve_text(context) if context else "（无）"

	resume_text = "（未指定）"
	if resume_name:
		loaded = _load_resume_text(ctx, resume_name)
		if loaded is None:
			return
		resume_text = loaded

	prompt = CHAT_REPLY_PROMPT.format(
		recruiter_message=recruiter_message,
		context=context_text,
		resume_text=resume_text,
		tone=tone,
	)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-reply", result,
		render=lambda d: render_ai_result(d, title="ai-reply"),
		hints={"next_actions": [
			"复制草稿到 BOSS 聊天框发送",
			"boss chatmsg <uid> 查看完整聊天历史（uid 见 boss chat 输出）",
		]},
	)


@ai_group.command("interview-prep")
@click.argument("jd_text")
@click.option("--resume", "resume_name", default=None, help="参考简历名称（可选，根据简历真实经历定制问题）")
@click.option("--count", default=10, type=int, help="题量，默认 10")
@click.pass_context
def ai_interview_prep_cmd(ctx: click.Context, jd_text: str, resume_name: str | None, count: int) -> None:
	"""基于目标职位生成模拟面试题

	JD_TEXT 是目标职位描述文本，或 @文件路径 读取文件内容。
	"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	if jd_text.startswith("@"):
		file_path = Path(jd_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		jd_text = file_path.read_text(encoding="utf-8")

	resume_text = "（未指定）"
	if resume_name:
		loaded = _load_resume_text(ctx, resume_name)
		if loaded is None:
			return
		resume_text = loaded

	prompt = INTERVIEW_PREP_PROMPT.format(
		jd_text=jd_text,
		resume_text=resume_text,
		count=count,
	)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-interview-prep", result,
		render=lambda d: render_ai_result(d, title="ai-interview-prep"),
		hints={"next_actions": [
			"对照 questions 逐题准备答案",
			"boss ai chat-coach <chat_text> 用于沟通准备",
		]},
	)


@ai_group.command("chat-coach")
@click.argument("chat_text")
@click.option("--resume", "resume_name", default=None, help="参考简历名称（可选）")
@click.option("--style", default="简洁专业", help="沟通风格偏好（如 简洁专业/积极主动/谨慎稳重）")
@click.pass_context
def ai_chat_coach_cmd(ctx: click.Context, chat_text: str, resume_name: str | None, style: str) -> None:
	"""基于聊天记录给出沟通技巧诊断与下一步建议

	CHAT_TEXT 是聊天记录文本，或 @文件路径 读取文件内容。
	"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	if chat_text.startswith("@"):
		file_path = Path(chat_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		chat_text = file_path.read_text(encoding="utf-8")

	resume_text = "（未指定）"
	if resume_name:
		loaded = _load_resume_text(ctx, resume_name)
		if loaded is None:
			return
		resume_text = loaded

	prompt = CHAT_COACH_PROMPT.format(
		chat_text=chat_text,
		resume_text=resume_text,
		style=style,
	)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-chat-coach", result,
		render=lambda d: render_ai_result(d, title="ai-chat-coach"),
		hints={"next_actions": [
			"按 next_action_recommendation 的建议行动",
			"message_templates 可直接复制发送",
		]},
	)


@ai_group.command("suggest-keywords")
@click.option("--limit", default=20, type=click.IntRange(min=1), help="候选池职位数上限")
@click.pass_context
def ai_suggest_keywords_cmd(ctx: click.Context, limit: int) -> None:
	"""基于候选池分析推荐搜索关键词组合"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
		shortlist = cache.list_shortlist()[:limit]

	if not shortlist:
		handle_output(
			ctx,
			"ai-suggest-keywords",
			{"keyword_groups": [], "patterns": [], "search_suggestions": []},
			render=lambda d: render_ai_result(d, title="ai-suggest-keywords"),
			hints={"next_actions": ["boss shortlist add <security_id> <job_id>"]},
		)
		return

	shortlist_data = json.dumps([
		{
			"title": item.get("title", ""),
			"company": item.get("company", ""),
			"city": item.get("city", ""),
			"salary": item.get("salary", ""),
			"tags": item.get("tags", ""),
		}
		for item in shortlist
	], ensure_ascii=False)

	prompt = SUGGEST_KEYWORDS_PROMPT.format(shortlist_data=shortlist_data)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	result.setdefault("keyword_groups", [])
	result.setdefault("patterns", [])
	result.setdefault("search_suggestions", [])
	handle_output(
		ctx,
		"ai-suggest-keywords",
		result,
		render=lambda d: render_ai_result(d, title="ai-suggest-keywords"),
		hints={"next_actions": [
			"boss search <推荐关键词>",
			"boss preset add <name> --query <关键词>",
		]},
	)


@ai_group.command("resume-optimize")
@click.argument("resume_name")
@click.option("--jd", "jd_text", default=None, help="目标职位描述文本或 @文件路径")
@click.option("--job-id", default=None, help="从缓存读取职位描述的 job_id")
@click.pass_context
def ai_resume_optimize_cmd(ctx: click.Context, resume_name: str, jd_text: str | None, job_id: str | None) -> None:
	"""基于目标岗位优化简历措辞（仅建议，不修改简历）"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	if not jd_text and not job_id:
		handle_error_output(ctx, "ai", code="INVALID_PARAM", message="需要指定 --jd 或 --job-id")
		ctx.exit(1)
		return

	# 从缓存加载 JD
	if job_id:
		with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
			jd_text = cache.get_job_desc(job_id)
		if not jd_text:
			handle_error_output(
				ctx, "ai",
				code="CACHE_MISS",
				message=f"job_id '{job_id}' 的职位描述未缓存",
				recoverable=True,
				recovery_action=f"boss detail <security_id> --job-id {job_id}",
			)
			ctx.exit(1)
			return

	# 支持 @file 语法
	if jd_text and jd_text.startswith("@"):
		file_path = Path(jd_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		jd_text = file_path.read_text(encoding="utf-8")

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	prompt = RESUME_OPTIMIZE_SIMPLE_PROMPT.format(jd_text=jd_text, resume_text=resume_text)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	handle_output(
		ctx, "ai-resume-optimize", result,
		render=lambda d: render_ai_result(d, title="ai-resume-optimize"),
		hints={"next_actions": [
			f"boss resume edit {resume_name}",
			f"boss ai optimize {resume_name} --jd <jd_text>",
		]},
	)


@ai_group.command("cover-letter")
@click.argument("resume_name")
@click.option("--jd", "jd_text", default=None, help="目标职位描述文本或 @文件路径")
@click.option("--job-id", default=None, help="从缓存读取职位描述的 job_id")
@click.option(
	"--tone", default="简洁专业", type=click.Choice(["简洁专业", "热情积极", "谨慎稳重"]), help="求职信语气"
)
@click.option("--lang", default="zh", type=click.Choice(["zh", "en"]), help="输出语言（zh 中文 / en 英文）")
@click.pass_context
def ai_cover_letter_cmd(
	ctx: click.Context, resume_name: str, jd_text: str | None, job_id: str | None, tone: str, lang: str
) -> None:
	"""基于本地简历与目标岗位起草求职信/自我介绍（仅草稿，不发送）"""
	svc = _require_ai_service(ctx)
	if svc is None:
		return

	if not jd_text and not job_id:
		handle_error_output(ctx, "ai", code="INVALID_PARAM", message="需要指定 --jd 或 --job-id")
		ctx.exit(1)
		return

	# 从缓存加载 JD（键为 encryptJobId）
	if job_id:
		with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
			jd_text = cache.get_job_desc(job_id)
		if not jd_text:
			handle_error_output(
				ctx, "ai",
				code="CACHE_MISS",
				message=f"job_id '{job_id}' 的职位描述未缓存",
				recoverable=True,
				recovery_action=f"boss detail <security_id> --job-id {job_id}",
			)
			ctx.exit(1)
			return

	# 支持 @file 语法
	if jd_text and jd_text.startswith("@"):
		file_path = Path(jd_text[1:])
		if not file_path.exists():
			handle_error_output(ctx, "ai", code="INVALID_PARAM", message=f"文件 '{file_path}' 不存在")
			ctx.exit(1)
			return
		jd_text = file_path.read_text(encoding="utf-8")

	resume_text = _load_resume_text(ctx, resume_name)
	if resume_text is None:
		return

	lang_label = "英文（English）" if lang == "en" else "中文"
	prompt = COVER_LETTER_PROMPT.format(jd_text=jd_text, resume_text=resume_text, tone=tone, lang=lang_label)
	result = _call_ai(ctx, svc, prompt)
	if result is None:
		return

	result.setdefault("greeting_opener", "")
	result.setdefault("cover_letter", "")
	result.setdefault("highlights", [])
	handle_output(
		ctx, "ai-cover-letter", result,
		render=lambda d: render_ai_result(d, title="ai-cover-letter"),
		hints={
			"note": "仅为 AI 生成的草稿，请自行核对真实性后再使用；本命令不发送任何消息",
			"next_actions": [
				f"boss ai interview-prep --jd <jd_text> --resume {resume_name}",
			],
		},
	)
